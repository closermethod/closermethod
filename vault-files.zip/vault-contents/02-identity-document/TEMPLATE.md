# 01-IDENTITY.md · TEMPLATE

*Paste this into your Claude Project. Fill in every section. Keep each answer to 1-3 sentences maximum. If you can't answer a section in 3 sentences, you don't know your business well enough yet. This is the doc that forces clarity.*

---

## Who I am

**My name and role:**
[Your name. Your title. The thing people introduce you as at a dinner party.]

**What I've done before this:**
[The career/life context that matters. Don't list a resume. Name the two or three things that still shape how you work.]

**Where I'm based:**
[City or country. Claude uses this for time zone context, local examples, and regional voice.]

---

## What I do

**My business, in one sentence a 7-year-old would understand:**
[If you can't say it simply, you don't understand it well enough yet.]

**The specific outcome I help people get:**
[Not "transformation." Not "clarity." The concrete, specific result they get from working with me. The before and after.]

**How I'm different from others who say they do the same thing:**
[The one thing that's true about you that almost none of your competitors can claim. If you can't name it, find it before filling this in.]

---

## Who I serve

**My ideal customer, in one sentence:**
[Demographics alone are weak. Add a psychographic. Example: "Women over 40 leaving corporate to start a consulting practice, who have the skills but freeze at the marketing."]

**What they're struggling with right now:**
[The exact problem they were googling the night before they found me.]

**What they've tried that didn't work:**
[Knowing what didn't work for them makes Claude's output sharper. It tells Claude what arguments NOT to lead with.]

**What they say out loud when they talk about the problem:**
[Write 3-5 phrases in their own words. Not your marketing language. Theirs. Claude will mirror this.]

---

## My principles

**Three things I will never do:**
1.
2.
3.

**Three things I always do:**
1.
2.
3.

**The belief that runs through everything I make:**
[One sentence. The worldview your business is built on. If a customer violates this belief, they're not the right customer.]

---

## How I want to sound

**Two creators, writers, or thinkers whose voice mine is closest to:**
1.
2.

**One creator, writer, or thinker I actively DON'T want to sound like:**
[Claude needs the negative example more than the positive one. Be specific about what to avoid.]

---

## What I'm building right now

**The main project, in one sentence:**
[This changes. Update it weekly. Claude uses this to decide what's relevant and what's noise.]

**The audience this specific project is for:**
[Sometimes this is your main audience. Sometimes it's a subset. Be specific.]

---

## Context for Claude

When you generate anything for me, respect this identity document. If something I ask for conflicts with what's in this document, flag it and ask before proceeding. Don't silently override.

---

*Fill this in once. Reread it quarterly. Rewrite when your business changes meaningfully.*
