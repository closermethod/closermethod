# 03-PRODUCT-LADDER.md · TEMPLATE

*What you sell, at what altitude, and to whom. Claude uses this to route every output to the right audience without asking. If you skip this, Claude will pitch your free lead magnet to people who should be seeing your high-ticket offer, and vice versa.*

---

## The ladder

Fill in every tier you have. Delete tiers you don't. Claude uses this to decide what to offer in any given context.

### Tier 0 · Free / Lead magnet

**What it is:**
[The free thing. Ebook, vault, template, quiz, waitlist.]

**The ask:**
[Email. Sometimes phone. Nothing else.]

**Who it's for:**
[Cold audience. People who just found you.]

**The URL:**
[Where to send them.]

**What happens after they opt in:**
[Name the email sequence. Claude uses this to route post-signup logic.]

---

### Tier 1 · Low ticket

**What it is:**
[The self-serve product. Templates, prompt library, digital download.]

**The altitude:**
[Price range, e.g., "under $100." Avoid listing exact price numbers here if you plan to share this document externally.]

**Who it's for:**
[People who've opted in and want to try your system on their own.]

**The URL:**
[Checkout page.]

**What it replaces:**
[The freelancer task, the tool, the consultant, the course they were going to buy. Be specific.]

---

### Tier 2 · Mid ticket

**What it is:**
[The structured program or done-with-you offer.]

**The altitude:**
[Price range.]

**Who it's for:**
[Buyers who bought Tier 1 and want more structure. OR: cold leads who skipped Tier 1.]

**The URL:**
[Sales page.]

**Delivery format:**
[Self-paced, cohort, 1:1, recorded, live, etc.]

---

### Tier 3 · High ticket

**What it is:**
[The premium offer. Done-for-you, private consulting, retreat, mastermind, event.]

**The altitude:**
[Price range.]

**Who it's for:**
[Buyers who have already bought lower tiers OR referrals OR enterprise/company budgets.]

**Not for:**
[Cold audience. Never pitched to cold.]

---

## Routing rules

Claude uses these to decide what to mention and when:

1. **If the person hasn't opted in yet**, route to Tier 0. Never jump to Tier 1 or above in first-touch content.

2. **If the person has opted in but hasn't bought**, route to Tier 1. Mention Tier 0 as a recent gift. Don't mention Tier 2 or 3 unless asked.

3. **If the person has bought Tier 1**, route to Tier 2. Frame it as "the next step after what you already have."

4. **If the person has bought Tier 2**, route to Tier 3 OR offer complementary Tier 1 products they haven't bought.

5. **Never stack tiers in the same piece of content.** One piece = one offer altitude. Mentioning three tiers in one page destroys conversion on all three.

6. **Free content talks about Tier 0 and Tier 1 only.** Paid content can reference higher tiers.

---

## The bridge between tiers

The psychological bridge from Tier N to Tier N+1 is:

- Tier 0 → 1: "You saw it work. Here's the whole system."
- Tier 1 → 2: "You built with the system. Here's how to scale with structure."
- Tier 2 → 3: "You have structure. Here's where the real acceleration happens."

Claude should use these framings when moving a reader up the ladder. Never use "upgrade" or "premium version." Always frame as the next obvious step.

---

## What's off-limits

**I don't sell:**
[Name anything you categorically won't offer. E.g., coaching, group coaching, 1:1, hourly consulting, affiliate products. Claude should never suggest these even if a reader asks for them.]

**I don't discount:**
[Your pricing policy. Never discount? Only during specific launches? Loyalty-only? Claude follows your rule.]

**I don't upsell to:**
[Specific customer segments you protect from upsells. E.g., "Buyers within 7 days of their first purchase." Or: "Anyone tagged 'refund' in the CRM."]

---

## The one thing

If you had to pick ONE product that defines your business, it's:

**[Tier X · Product Name]**

Claude defaults to this one when context is unclear. Everything else is a route off of this center.

---

*Update this whenever you launch a new tier, retire an old one, or change your pricing strategy. Otherwise, it stays locked.*
