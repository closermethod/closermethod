# 01 · PROJECT FILE STRUCTURE

*How to organize a Claude Project so outputs ship finished, not half-built.*

---

## The problem this solves

You open Claude. You have a product to build. You type the prompt. Claude responds, but it's missing half the context. You spend the next 45 minutes re-explaining your business, your voice, your audience. By the time the output is usable, you've burned 60% of your token limit on re-introduction.

This file structure fixes that.

---

## The 4-file rule

Every Claude Project should have exactly 4 files in this order:

```
[Project Name] HQ/
├── 01-IDENTITY.md          ← Who you are, who you serve
├── 02-VOICE-RULES.md       ← How you write, what you never say
├── 03-PRODUCT-LADDER.md    ← What you sell, to whom, at what price altitude
└── 04-CURRENT-FOCUS.md     ← What you're actively building this week
```

The first three are set once and rarely touched. The fourth is rewritten every Monday morning.

---

## Naming convention rules

- Always prefix with `01`, `02`, `03`, `04` so Claude reads them in order when you say "read all project files."
- Always use uppercase file names inside the Project. It makes them stand out in Claude's file viewer.
- Always use `.md` (markdown) instead of `.txt`. Claude parses markdown natively and respects hierarchy.
- Never name a file "notes" or "context." Claude can't tell which context is priority when the name is generic. Specific beats clever.

---

## The startup ritual

Every new conversation in the Project starts with this exact message:

> Read all project files before responding. Then acknowledge you've read them and briefly confirm the 2-3 most important things I've told you in them.

Claude will list them. If Claude lists them wrong, your files aren't clear enough. Fix the files, not the prompt.

---

## The override rule

Sometimes you want Claude to ignore your voice rules. For example, when drafting an investor email in a register you don't normally use. The override looks like this:

> For this task only, ignore rule 3 in 02-VOICE-RULES.md. Use professional formal tone instead.

Explicit overrides work. Implicit ones don't. If you just say "be more formal," Claude will guess and half-apply it. Name the rule you're overriding.

---

## What goes in 04-CURRENT-FOCUS.md

This is the file most people skip, and it's the one that makes the biggest difference.

Rewrite it every Monday. 5 minutes. The format:

```
# Current Focus · Week of [Date]

## What I'm building
[One sentence. The main product or deliverable.]

## Who it's for
[One sentence. The specific person who will use/buy it.]

## What's done
[Bullet list of what's already shipped this week.]

## What's next
[Bullet list of the next 3 actions, in order.]

## What's not relevant right now
[Bullet list of topics Claude should actively avoid pulling in unless asked.]
```

The last section is the magic. Telling Claude what *not* to pull in is usually more useful than telling it what to pull in. If you don't want last quarter's launch referenced, say so.

---

## When to break the 4-file rule

When you have more than one distinct product line or business, create separate Projects. Don't stack products into one Identity document. One Project = one offer = one audience.

If you're a coach and a software founder, those are two Projects. If you're a UGC creator and an agency owner, those are two Projects. Claude handles context switching badly when too many identities are in the same container.

---

## Common mistakes

- **Too long.** Each file should be under 800 words. Claude re-reads them on every conversation and long files eat your token budget.
- **Too vague.** "We help entrepreneurs" is not an identity. "We help women over 40 pivot out of corporate into solo consulting" is.
- **No current focus.** If 04-CURRENT-FOCUS.md is empty, Claude has no idea what's actually in front of you right now. It'll pull stale context.
- **Editing in chat.** Never ask Claude to update your project files through a chat message. Edit them in the Project file viewer directly. Chat edits don't persist.

---

Next file: **02 · Identity Document**
