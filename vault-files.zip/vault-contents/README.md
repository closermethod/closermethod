# THE WORKFLOW VAULT

*The file system Elisabeth uses to run her business inside Claude. Built through 100+ shipped products.*

---

## How to use this

This vault is four documents. You paste them into Claude once, inside a Project, and every conversation after that starts with context instead of cold.

The order matters:

1. **01 · Project File Structure.** How Claude reads your files. Set this up first.
2. **02 · Identity Document.** Who you are. This is the one that makes Claude stop sounding like ChatGPT.
3. **03 · Voice & Output Rules.** The constraints. This is the one that makes Claude ship a finished product instead of a draft.
4. **04 · Product Ladder.** What you sell and to whom. This is the one that makes Claude route outputs to the right audience without being asked.

---

## The 2-minute setup

1. Open Claude. Create a new Project called `[Your Business Name] HQ`.
2. Open folder `01-project-file-structure` and follow the naming convention.
3. Copy `02-identity-document/TEMPLATE.md` into a text editor. Fill it out with your info. Drop the filled-in version into your Project files.
4. Do the same with `03-voice-output-rules/TEMPLATE.md` and `04-product-ladder/TEMPLATE.md`.
5. Start any new chat with: "Read all project files before responding. Then acknowledge you've read them."

Claude will confirm, and from that point every output is context-aware.

---

## The one rule

Don't skip filling in your own information. The templates work because they force Claude to understand you. If you paste generic answers, you get generic output. Spend 20 minutes filling these in once. You will not spend that time again.

---

## What to do next

If you got the vault from the Closer Method website, you've probably already seen the AI Brain Builder. If you haven't, go build yours now: closermethod-brain-builder.netlify.app

The Brain Builder generates document `02` for you from four taps. If you hate filling in templates, use it. If you prefer writing your own, use the template in `02-identity-document`.

Either works. Both together is faster.

---

Built by Elisabeth Hitz
The Closer Method · closermethod.com
